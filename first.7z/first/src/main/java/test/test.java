package test;

public class test {
	
	public static void main(String[] args)
	{
		try{
			String str = "abc";
			Integer.parseInt(str);
		}catch(Exception e){
			System.out.println("Error");
		}
	}

}
