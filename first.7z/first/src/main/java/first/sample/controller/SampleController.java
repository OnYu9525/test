package first.sample.controller;

import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.collections.map.HashedMap;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.fasterxml.jackson.annotation.JsonCreator.Mode;

import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;
import first.common.common.CommandMap;
import first.sample.service.SampleService;

@Controller
public class SampleController 
{
	Logger log = Logger.getLogger(this.getClass()); //�α� ���
	
	@Resource(name="sampleService")
	private SampleService sampleService; //���ü��� �����ϰ�
	
	
	
	@RequestMapping(value="/sample/openBoardSearch.do")
	public ModelAndView openBoardSearch(CommandMap commandMap) throws Exception
	{
		ModelAndView mv = new ModelAndView("/sample/boardSearch");
		return mv;
	}
	
	
	@RequestMapping(value="/sample/openBoardList.do") //��� �������ְ�~
	public ModelAndView openBoardList(CommandMap commandMap) throws Exception
	{  //�𵨺� ����� openSampleBoardList �޼��� �����
		ModelAndView mv = new ModelAndView("/sample/boardList"); //�𵨺� ��ü ����� jsp���� ����
		
		log.debug("����?"+commandMap.getMap());
		if(!commandMap.containsKey("search")){
			commandMap.getMap().put("search", 0);
			commandMap.getMap().put("vals", "");
		}else{
			commandMap.getMap().put("search", Integer.parseInt((String) commandMap.getMap().get("search")));
			
		}
		
		log.debug("IF�� ��"+commandMap.getMap());
		Map<String, Object> resultMap = sampleService.selectBoardList(commandMap.getMap());
		//List<Map<String, Object>> list = sampleService.selectBoardList(commandMap);
		//�տ��� ���ü��� �����Ѱ� �ڿ� selectBoardList��� �޼��� ����� 
		//mv.addObject("list", list); //�տ��� ���� ���ϰ� list�� ���� list��� �����ϰ�
		
		mv.addObject("paginationInfo", (PaginationInfo)resultMap.get("paginationInfo"));
		mv.addObject("list", resultMap.get("result"));
		
		PaginationInfo page=(PaginationInfo)resultMap.get("paginationInfo");
		mv.addObject("total",page.getTotalRecordCount());
		mv.addObject("search",commandMap.getMap().get("search") );
		mv.addObject("vals",commandMap.getMap().get("vals") );
		System.out.println();
		System.out.println("========JRebel Test============");
		log.debug("======JRebel Test2======");
		
		return mv;
		
		
	}
	
	@RequestMapping(value="/sample/testMapArgumentResolver.do")
	public ModelAndView testMapArgumentResolver(CommandMap commandMap) throws Exception
	{
		ModelAndView mv = new ModelAndView("");
		
		if(commandMap.isEmpty() == false)
		{
			Iterator<Entry<String,Object>> iterator = commandMap.getMap().entrySet().iterator();
			Entry<String,Object> entry = null;
			while(iterator.hasNext())
			{
				entry = iterator.next();
				log.debug("key :"+entry.getKey()+", value :"+entry.getValue());
			}
		}
		
		return mv;
	}
	
	
	@RequestMapping(value="/sample/openBoardWrite.do")
	public ModelAndView openBoardWrite(CommandMap commandMap) throws Exception
	{
		
		ModelAndView mv = new ModelAndView("/sample/boardWrite");  //JSP ���� ����
		System.out.println("========JRebel Test============");
		return mv;
	}
	
	@RequestMapping(value="/sample/Test.do")
	public ModelAndView Test(CommandMap commandMap) throws Exception
	{
		
		ModelAndView mv = new ModelAndView("/sample/Test");  //JSP ���� ����
		System.out.println("========Test Test============");
		return mv;
	}
	
	@RequestMapping(value="/sample/kk.do")
	public ModelAndView kk(CommandMap commandMap) throws Exception
	{
		
		ModelAndView mv = new ModelAndView("/sample/kk");  //JSP ���� ����
		System.out.println("========kk Test============");
		return mv;
	}
	
	
	
	
	@RequestMapping(value="/sample/insertBoard.do")
	public ModelAndView insertBoard(CommandMap commandMap, HttpServletRequest request) throws Exception
	{
		ModelAndView mv = new ModelAndView("redirect:/sample/openBoardList.do");
		
		sampleService.insertBoard(commandMap.getMap(), request);
		
		return mv;
	}
	
	@RequestMapping(value="/sample/openBoardDetail.do")
	public ModelAndView openBoardDetail(CommandMap commandMap) throws Exception
	{
		ModelAndView mv = new ModelAndView("/sample/boardDetail");
		log.debug("������ �Է°���?"+commandMap.getMap());
		
		
		commandMap.getMap().put("search", Integer.parseInt((String) commandMap.getMap().get("search")));
			
		
		log.debug("������ if�� �� �Է°���?"+commandMap.getMap());
		
		Map<String,Object> map = sampleService.selectBoardDetail(commandMap.getMap());
		
		mv.addObject("map", map.get("map"));
		mv.addObject("list", map.get("list")); //��� ÷������ ��� �θ��� ������
		mv.addObject("search",commandMap.getMap().get("search") );
		mv.addObject("vals",commandMap.getMap().get("vals") );
		mv.addObject("total",commandMap.getMap().get("total") );
		return mv;
	}
	
	@RequestMapping(value="/sample/openBoardUpdate.do")  //����������ȭ��
	public ModelAndView openBoardUpdate(CommandMap commandMap) throws Exception
	{
		ModelAndView mv = new ModelAndView("/sample/boardUpdate");
		
		Map<String, Object> map = sampleService.boardUpdate(commandMap.getMap());
		
		mv.addObject("map", map.get("map"));  //����
		mv.addObject("list", map.get("list"));   //÷������
		
		return mv;
	}
	
	@RequestMapping(value="/sample/updateBoard.do")  //�����ϱ� ������~~ Ȥ�� �����ϱ� ������~~
	public ModelAndView updateBoard(CommandMap commandMap, HttpServletRequest request) throws Exception
	{
		ModelAndView mv = new ModelAndView("redirect:/sample/openBoardDetail.do");
		
		sampleService.updateBoard(commandMap.getMap(), request);
		
		mv.addObject("IDX", commandMap.get("IDX"));
		return mv;
	}
	
	@RequestMapping(value="/sample/deleteBoard.do")
	public ModelAndView deleteBoard(CommandMap commandMap) throws Exception
	{
		ModelAndView mv = new ModelAndView("redirect:/sample/openBoardList.do");
		
		sampleService.deleteBoard(commandMap.getMap());
		
		return mv;
	}

	
}
